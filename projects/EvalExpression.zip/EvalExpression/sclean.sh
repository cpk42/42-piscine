rm *~
rm *#